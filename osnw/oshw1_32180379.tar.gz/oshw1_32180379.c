#include <stdio.h>
#include <unistd.h>
#include <wait.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char *argv[]){
	pid_t pid;  //변수 선언

	if(argc < 4){
		printf("[usage] : ./oshw1_32184682 x y interval\n");
		printf("[condition] : x,y, and interval are positive integers.\n");
		exit(0);
	} // x, y, interval 중 입력 값 없을 시 오류 방지
	int status;   //변수 설정
	int x = 0;    //변수 초기값
	int y = 0;
	int interval = 0;
	x= atoi(argv[1]);  //각 x, y, interval에 프로그램 실행 시 받아온 매개변수 대입
	y= atoi(argv[2]);
	interval= atoi(argv[3]);
	//printf("x = %d, y = %d, interval = %d\n", x, y, interval); // 실행시 입력받은 매개변수 확인
	int sum = 0;
	pid = fork();  //자식프로세스 생성
	if(pid > 0){           //부모프로세스
		wait(&status);
		if(WEXITSTATUS(status) == 1 ){  //자식 코드가 1인 경우 1000
			printf("Parent says that it is 1000.\n");
			return 0;
		}
		else if(WEXITSTATUS(status) == 2){  //자식 코드가 2인 경우 1000 초과
			printf("Parent says that it is greater than 1000.\n");
			return 0;
		}
		else if(WEXITSTATUS(status) == 0) {  //자식 코드가 0인 경우 1000 미만
			printf("Parent says that it is less than 1000.\n");
			return 0;
		}
		else{                 //자식 종료코드가 3인 경우 종료
			return 0;
		}
	}
	else if(pid == 0){     //자식프로세스
		if(x<=0 || y<=0 || interval<=0){   //정상입력 확인
			if(x<=0){
				printf("x is not a positive integer\n");  //x 정상입력 확인
			}
			if(y<=0){
				printf("y is not a positive integer\n");  //y 정상입력 확인
			}
			if(interval<=0){                                  //z 정상입력 확인
				printf("interval is not a positive integer\n");
			}
			exit(3);      //비정상 입력 시 종료코드 3
		}
		else{
			for(int i=x; i<= y; i+=interval){     //입력값 더한 총합 계산
				sum = sum+i;
			}
			printf("Child says that sum of numbers from %d to %d with interval of %d is %d.\n", x, y, interval, sum);  //자식프로세스 출력
			if(sum < 1000){
				exit(0);      //총합이 1000 미만 일때 0
			}
			else if(sum == 1000){
				exit(1);      //총합이 1000 일때 1
			}
			else{
				exit(2);      //총합이 1000 초과 일때 2
			}
		}
	}
	else{
		printf("자식 프로세스 생성 실패!\n");     //fork 실패
		return 0;
	}

}

